Map key CLI system utilities to ambients targeting template or custom decision branch.

  

Ie

1. Karpathy wordgenerator, feature extractor
2. PDF write or io adaptor: pandoc
3. FFmpeg adapter
4. Custom Repo Userspace adapter