Linus Torvalds

Geoffery Hinton

Ilya Suskever

Elon Musk

Jaron Lanier

Richard Stallman

Vincent Cerf

Timothy Berners Lee

Peter Shore

Brendan Eich

Brian Kerninghan

Anders Hejlsberg