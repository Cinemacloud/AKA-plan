[https://threejs.org/examples/#webgl_materials_envmaps](https://threejs.org/examples/#webgl_materials_envmaps)

Envmap with sphere inversion, randomize map to image and feed curateWallArtData

Hakim 3D, Fullpage.js, Hypercards