1. Coder [https://github.com/coder](https://github.com/coder) - Browser VSCode
2. LIBP2P.js
3. MLrun and MLRoute
4. Containter2wasm
5. Emscripten c to wasm
6. BrowserFS API [https://github.com/GoogleChromeLabs/browser-fs-access](https://github.com/GoogleChromeLabs/browser-fs-access?tab=readme-ov-file)
7. Piper TTS+ https://github.com/Mintplex-Labs/piper-tts-web

[[UI Ideas]]

[[Continous Dialogos Integration]]

[[Autonomouse Code Generator]]