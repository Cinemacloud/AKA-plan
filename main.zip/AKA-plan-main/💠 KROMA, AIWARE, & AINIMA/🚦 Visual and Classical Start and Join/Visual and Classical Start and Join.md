The nervous system of Kroma is realizing distributed & decentralized BNEC, follwed by discovery key via decentralized and standards-only methods decoupling classic cloud and domain-based centralization and scaling. This focuses on tapping into, pooling, and sharing edge as infrastructure and autonomy.

Monadic identifers are ICE candidates

- Visual QR 1-n || m-n →monadicID (MID)
- Classic DNS TXT →MiD
- Location-mid MID Signals
- CRDT SharedArrayBuffer Nexus Object Over Hyperring

MiDs lightly emulate Raft protocol in 3 possible states: follower, candidate, and leader.

MiDs are mapped into Hyperring, a which is a hyperspherical flatmap of followers.

Therefore each MiD is n-* and represents the cloudless RTDatachannel stream.

  

[[TLS DTLS and SRTP]]

[[ITS - ICE TURN STUN]]