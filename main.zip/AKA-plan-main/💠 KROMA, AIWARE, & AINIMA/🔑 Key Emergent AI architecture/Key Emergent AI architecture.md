New LPU paradigm (AIOSA)

  

1. Ring attention,
2. Cot/Tot/Got
3. DSpy (TextGrad -> ProTeGi*),
4. ICL(+)/RLHF/self-rag/speculative rag
5. ReAct (reasoning acting),
6. Dpo-P
7. Auralux

… Later, latent hysteresis snn temporal coding, structural grokking.

Q(s,a)<-Q(s,a) + a[r + y*max_[a]Q(s',a) - Q(s,a)]

  

[[ML Data Providance]]

[[Dev vs Consumer “Artefacts”]]